import pandas as pd
import nltk
import re
stemmer = nltk.SnowballStemmer("english")
from nltk.corpus import stopwords
import string
import warnings
warnings.filterwarnings("ignore")
import nltk
nltk.download('stopwords')
stopwords_set =  set(stopwords.words('english'))
df = pd.read_csv('go_emotions_dataset.csv')
#we clean up unnecessary marks
def clean(text):
    text = str(text).lower()# 转换成小写
    text = re.sub('\[.*?\]', '', text)
    text = re.sub('https?://\S+|www\.\S+', '', text)
    text = re.sub('<.*?>+', '', text)
    text = re.sub('[%s]' % re.escape(string.punctuation), '', text)
    text = re.sub('\n', '', text)
    text = re.sub('\w*\d\w*', '', text)
    text = re.sub('[^a-zA-Z\s]', '', text)# filter non English char
    text = [word for word in text.split(' ') if word not in stopwords_set]
    text=" ".join(text)
    text = [stemmer.stem(word) for word in text.split(' ')]
    text=" ".join(text)
    return text

df['token'] = df['text'].apply(clean)
df.to_csv('emotions_token.csv',index = False)